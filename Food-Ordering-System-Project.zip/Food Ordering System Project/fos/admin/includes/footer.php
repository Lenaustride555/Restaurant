<div class="footer">
            
            <div>
                <strong>Copyright @</strong> Food Ordering System &copy;<?php echo date('Y');?>
            </div>
        </div>